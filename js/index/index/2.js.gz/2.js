// 设置宽
const hh = $('.index-2-hot-content-2-item-content').width()-$('.index-2-hot-content-2-item-img').width();
$('.index-2-hot-content-2-item-text').width(hh-10);